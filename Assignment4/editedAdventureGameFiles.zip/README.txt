Extra Credit Changes from Original
Only Edited AdventureGame.java
- Added Sidebar containing overall moves 
- Changed Icons
- Added Restart, Quit, or explore pop up on finding treasure
- Added Restart, Quit, or explort pop up on death of adventurer
- shows total moves on finding treasure


